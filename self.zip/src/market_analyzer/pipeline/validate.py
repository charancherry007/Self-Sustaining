"""Validation layer: freshness and sanity checks.

The analyzer is fail-closed. If data is stale, malformed, or too thin, the
instrument is rejected rather than analysed on bad numbers.
"""

from __future__ import annotations

from datetime import datetime, timezone

from market_analyzer.models.analysis import DataQualityReport
from market_analyzer.models.quote import Candle, Quote


def candle_age_seconds(candles: list[Candle]) -> float | None:
    if not candles:
        return None
    newest = max(c.timestamp for c in candles)
    return (datetime.now(timezone.utc) - newest).total_seconds()


def validate_candles(
    symbol: str,
    candles: list[Candle],
    stale_after_seconds: int,
    session_open: bool = True,
    session_close_utc: datetime | None = None,
) -> list[str]:
    """Return a list of issues. Empty list means the series looks usable."""
    issues: list[str] = []

    if not candles:
        return [f"{symbol}: no candles"]

    timestamps = [c.timestamp for c in candles]
    if timestamps != sorted(timestamps):
        issues.append(f"{symbol}: candles are not in ascending timestamp order")
    if len(set(timestamps)) != len(timestamps):
        issues.append(f"{symbol}: duplicate candle timestamps")

    bad_ohlc = [c.timestamp for c in candles if not c.is_valid_ohlc]
    if bad_ohlc:
        issues.append(f"{symbol}: {len(bad_ohlc)} candle(s) with invalid OHLC ordering")

    non_positive = [c for c in candles if c.close <= 0]
    if non_positive:
        issues.append(f"{symbol}: {len(non_positive)} candle(s) with non-positive close")

    newest = max(c.timestamp for c in candles)
    now = datetime.now(timezone.utc)

    if session_open:
        age = (now - newest).total_seconds()
        if age > stale_after_seconds:
            issues.append(f"{symbol}: data is stale ({age:.0f}s > {stale_after_seconds}s)")
    else:
        # Outside market hours, bars naturally stop updating after the market closes.
        # Verify the newest bar is from or near the most recent session close.
        if session_close_utc:
            diff_from_close = abs((session_close_utc - newest).total_seconds())
            session_age = (now - session_close_utc).total_seconds()
            if diff_from_close > 7200 or session_age > (5 * 86400):
                issues.append(
                    f"{symbol}: closed session data is outdated ({diff_from_close:.0f}s from close)"
                )
        else:
            closed_max_age = 4 * 86400
            age = (now - newest).total_seconds()
            if age > closed_max_age:
                issues.append(f"{symbol}: closed market data is older than 4 days ({age:.0f}s)")

    return issues


def validate_quote(quote: Quote, stale_after_seconds: int) -> list[str]:
    issues: list[str] = []
    if quote.last <= 0:
        issues.append(f"{quote.symbol}: non-positive quote")
    if quote.bid is not None and quote.ask is not None and quote.bid > quote.ask:
        issues.append(f"{quote.symbol}: crossed market (bid > ask)")
    age = quote.age_seconds
    if age is not None and age > stale_after_seconds:
        issues.append(f"{quote.symbol}: quote is stale ({age:.0f}s)")
    return issues


def build_data_quality_report(
    provider: str,
    realtime: bool,
    requested: list[str],
    failed: set[str],
    stale: set[str],
    issues: list[str],
) -> DataQualityReport:
    return DataQualityReport(
        provider=provider,
        realtime=realtime,
        instruments_requested=len(requested),
        instruments_ok=len(requested) - len(failed) - len(stale),
        instruments_stale=len(stale),
        instruments_failed=len(failed),
        issues=issues[:50],
    )
